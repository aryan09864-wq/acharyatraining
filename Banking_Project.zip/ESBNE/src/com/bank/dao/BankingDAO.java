package com.bank.dao;
import java.sql.*;

public class BankingDAO {
    // FIXES THE "connect() is undefined" ERROR
	private Connection connect() throws SQLException {
	    // REMOVE the ; from after esbne_db
	    return DriverManager.getConnection("jdbc:mysql://localhost:3306/esbne_db", "root", "akashnaiks@123");
	}
    public boolean registerCustomer(String user, String pass, double bal, String dob, String phone, String gender, String email) {
        String sqlUser = "INSERT INTO users (username, password_hash, dob, phone, gender, email) VALUES (?, ?, ?, ?, ?, ?)";
        String sqlAccount = "INSERT INTO accounts (username, balance) VALUES (?, ?)";

        try (Connection conn = connect()) {
            conn.setAutoCommit(false); // Start Transaction

            try (PreparedStatement ps1 = conn.prepareStatement(sqlUser);
                 PreparedStatement ps2 = conn.prepareStatement(sqlAccount)) {
                
                // 1. Insert into Users
                ps1.setString(1, user);
                ps1.setString(2, pass); // This should be the hash from Service
                ps1.setString(3, dob);
                ps1.setString(4, phone);
                ps1.setString(5, gender);
                ps1.setString(6, email);
                ps1.executeUpdate();

                // 2. Insert into Accounts
                ps2.setString(1, user);
                ps2.setDouble(2, bal);
                ps2.executeUpdate();

                conn.commit(); // Save both!
                System.out.println("✅ Database Updated: User & Account created.");
                return true;
            } catch (SQLException e) {
                conn.rollback();
                System.out.println("❌ SQL Error: " + e.getMessage());
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public String loginUser(String user, String pass) {
        String sql = "SELECT username FROM users WHERE username = ? AND password_hash = ?";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, user);
            pstmt.setString(2, pass);
            ResultSet rs = pstmt.executeQuery();
            return rs.next() ? rs.getString("username") : null;
        } catch (SQLException e) { return null; }
    }

    public double getBalance(String user) {
        // We join users and accounts to find the balance for the specific username
        String sql = "SELECT a.balance FROM accounts a JOIN users u ON a.username = u.username WHERE u.username = ?";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, user);
            ResultSet rs = pstmt.executeQuery();
            return rs.next() ? rs.getDouble("balance") : 0.0;
        } catch (SQLException e) { 
            e.printStackTrace();
            return 0.0; 
        }
    }

    public boolean processTransaction(String user, double amount, String type, String hash) {
        String updateSql = "UPDATE accounts SET balance = balance + ? WHERE username = ?";
        String logSql = "INSERT INTO transactions (account_number, amount, transaction_type, security_hash) " +
                        "SELECT account_number, ?, ?, ? FROM accounts WHERE username = ?";

        try (Connection conn = connect()) {
            conn.setAutoCommit(false); // 1. Start Transaction

            try (PreparedStatement p1 = conn.prepareStatement(updateSql);
                 PreparedStatement p2 = conn.prepareStatement(logSql)) {
                
                // Update Balance
                p1.setDouble(1, amount);
                p1.setString(2, user);
                p1.executeUpdate();

                // Log Transaction (This fixes your empty Statement)
                p2.setDouble(1, Math.abs(amount));
                p2.setString(2, type);
                p2.setString(3, hash);
                p2.setString(4, user);
                p2.executeUpdate();

                conn.commit(); // 2. MUST COMMIT TO SAVE CHANGES
                return true;
            } catch (SQLException e) {
                conn.rollback(); // Undo everything if there's an error
                e.printStackTrace();
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void viewStatement(String user) {
        // We join transactions with accounts to find records belonging to the user
    	// Inside BankingDAO.viewStatement
    	String sql = "SELECT t.* FROM transactions t " +
    	             "JOIN accounts a ON t.account_number = a.account_number " +
    	             "WHERE a.username = ? ORDER BY t.timestamp DESC";
                     
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, user);
            ResultSet rs = pstmt.executeQuery();
            System.out.println("\n--- " + user.toUpperCase() + "'S TRANSACTION HISTORY ---");
            while (rs.next()) {
                System.out.println(rs.getTimestamp("timestamp") + " | " + 
                                   rs.getString("transaction_type") + " | $" + 
                                   rs.getDouble("amount"));
            }
        } catch (SQLException e) { 
            System.out.println("❌ Statement Error: " + e.getMessage());
            e.printStackTrace(); 
        }
    }
}