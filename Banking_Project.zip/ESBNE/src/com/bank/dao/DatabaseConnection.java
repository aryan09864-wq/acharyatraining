package com.bank.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    // Added SSL and Public Key fixes to the URL
    private static final String URL = "jdbc:mysql://localhost:3306/esbne_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    
    // IF USING XAMPP: Leave password as ""
    // IF USING WORKBENCH: Change to your actual password (e.g., "root" or "password")
    private static final String USER = "root"; 
    private static final String PASSWORD = "akashnaiks@123"; 

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}