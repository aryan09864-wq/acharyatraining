package com.bank.main;

import com.bank.service.BankingService;
import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        BankingService service = new BankingService();
        Scanner sc = new Scanner(System.in);

        System.out.println("============================================");
        System.out.println("   ENTERPRISE SECURE BANKING SYSTEM (ESBNE)   ");
        System.out.println("============================================");

        while (true) {
            System.out.println("\n1. Login\n2. Register (Full KYC)\n3. Exit");
            System.out.print("Choose Option: ");
            int choice = sc.nextInt();
            sc.nextLine(); 

            if (choice == 1) {
                System.out.print("Enter Username: "); String u = sc.nextLine();
                System.out.print("Enter Password: "); String p = sc.nextLine();

                String loggedInUser = service.login(u, p);
                if (loggedInUser != null) {
                    showCustomerMenu(service, loggedInUser, sc);
                } else {
                    System.out.println("❌ Invalid Credentials!");
                }
            } else if (choice == 2) {
                System.out.println("\n--- New Account Registration ---");
                System.out.print("Set Username: "); String u = sc.nextLine();
                System.out.print("Set Password: "); String p = sc.nextLine();
                System.out.print("DOB (YYYY-MM-DD): "); String dob = sc.nextLine();
                System.out.print("Phone Number: "); String ph = sc.nextLine();
                System.out.print("Gender: "); String gen = sc.nextLine();
                System.out.print("Email Address: "); String em = sc.nextLine();
                System.out.print("Initial Deposit: "); double bal = sc.nextDouble();

                service.register(u, p, bal, dob, ph, gen, em);
            } else if (choice == 3) {
                System.out.println("Shutting down ESBNE system... Goodbye!");
                sc.close();
                System.exit(0); // This completely kills all active connections and threads
            }else {
                System.out.println("Invalid choice. Please select 1, 2, or 3.");
            } 
        }
    }
    private static void showCustomerMenu(BankingService service, String user, Scanner sc) {
        while (true) {
            System.out.println("\n--- Welcome " + user + " ---");
            System.out.println("1. Deposit\n2. Withdraw\n3. Balance\n4. Statement\n5. Logout");
            System.out.print("Action: ");
            int action = sc.nextInt();

            if (action == 1) {
                System.out.print("Amount: ");
                service.deposit(user, sc.nextDouble());
            } else if (action == 2) {
                System.out.print("Amount: ");
                service.withdraw(user, sc.nextDouble());
            } else if (action == 3) {
                service.printBalance(user);
            } else if (action == 4) {
                service.viewStatement(user);
            } else if (action == 5) {
                service.notifyLogout(user); // Fixed: Passing 'user' string
                break;
            }
        }
    }
}