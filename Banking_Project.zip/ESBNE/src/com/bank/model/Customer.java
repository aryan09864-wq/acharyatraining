package com.bank.model;

public class Customer extends User {
    private double balance;
    private String accountId;

    public Customer(String username, String passwordHash, String accountId, double balance) {
        super(username, passwordHash, "CUSTOMER");
        this.accountId = accountId;
        this.balance = balance;
    }

    public double getBalance() { return balance; }
    public String getAccountId() { return accountId; }
    public void setBalance(double balance) { this.balance = balance; }
}