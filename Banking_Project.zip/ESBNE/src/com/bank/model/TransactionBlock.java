package com.bank.model;

import com.bank.service.SecurityUtil;
import java.util.Date;

public class TransactionBlock {
    private String transactionId;
    private String accountId;
    private double amount;
    private long timeStamp;
    private String previousHash;
    private String currentHash;

    public TransactionBlock(String transactionId, String accountId, double amount, String previousHash) {
        this.transactionId = transactionId;
        this.accountId = accountId;
        this.amount = amount;
        this.previousHash = previousHash;
        this.timeStamp = new Date().getTime();
        this.currentHash = calculateHash();
    }

    public String calculateHash() {
        String dataToHash = transactionId + accountId + amount + timeStamp + previousHash;
        return SecurityUtil.hashData(dataToHash); 
    }

    public String getCurrentHash() { return currentHash; }
    
    @Override
    public String toString() {
        return "TXN: " + transactionId + " | User: " + accountId + " | Amount: $" + amount + "\n   Hash: " + currentHash;
    }
}