package com.bank.service;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class NotificationService {
    
    // --- TELEGRAM BOT CREDENTIALS ---
    // Paste the Token from @BotFather here
    private static final String BOT_TOKEN = "8675164304:AAFPmq0ECATfIyTrrkUg-ym8gFUQz65Hxrc";
    
    // Paste your personal ID from @userinfobot here
    private static final String CHAT_ID = "5368924206";

    public void sendSMS(String message) {
        System.out.println("📱 [SYSTEM] Sending Telegram Alert to your phone...");
        
        try {
            // Encode the message to handle spaces and symbols
            String encodedMessage = URLEncoder.encode(message, "UTF-8");
            
            // The official Telegram API URL
            String requestUrl = "https://api.telegram.org/bot" + BOT_TOKEN + 
                                "/sendMessage?chat_id=" + CHAT_ID + 
                                "&text=" + encodedMessage;

            URL url = new URL(requestUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            int responseCode = conn.getResponseCode();
            
            if (responseCode == 200) {
                System.out.println("✅ [TELEGRAM SUCCESS] Alert delivered to your phone!");
            } else {
                System.out.println("❌ [TELEGRAM ERROR] Failed to send. Check your Token and Chat ID.");
            }
        } catch (Exception e) {
            System.out.println("❌ [TELEGRAM FAILED] Network error.");
        }
    }
}