package com.bank.service;
import com.bank.dao.BankingDAO;

public class BankingService {
    private BankingDAO dao = new BankingDAO();
    private NotificationService smsEngine = new NotificationService();
    private FraudDetectionEngine fraudEngine = new FraudDetectionEngine();

    public void register(String user, String pass, double balance, String dob, String phone, String gender, String email) {
        String hashed = SecurityUtil.hashData(pass);
        if (dao.registerCustomer(user, hashed, balance, dob, phone, gender, email)) {
            System.out.println("✅ Account Created!");
            smsEngine.sendSMS("Welcome " + user + "! Your account is active.");
        }
    }

    public String login(String user, String pass) {
        String authenticatedUser = dao.loginUser(user, SecurityUtil.hashData(pass));
        
        if (authenticatedUser != null) {
            // THIS IS THE TRIGGER: It sends the Telegram message
            smsEngine.sendSMS("🛡️ Security Alert: [" + authenticatedUser + "] has just logged into the ESBNE Banking System.");
            return authenticatedUser;
        }
        return null;
    }

    public void deposit(String user, double amount) {
        String hash = SecurityUtil.hashData(user + amount + System.currentTimeMillis());
        if (dao.processTransaction(user, amount, "DEPOSIT", hash)) {
            smsEngine.sendSMS("Deposit: $" + amount + " successful.");
        }
    }

    public void withdraw(String user, double amount) {
        if (fraudEngine.isFraudulent(amount)) {
            smsEngine.sendSMS("🚨 ALERT: High-value withdrawal blocked!");
            return;
        }
        String hash = SecurityUtil.hashData(user + amount + System.currentTimeMillis());
        if (dao.processTransaction(user, -amount, "WITHDRAWAL", hash)) {
            smsEngine.sendSMS("Withdrawal: $" + amount + " successful.");
        }
    }

    public void notifyLogout(String user) {
        smsEngine.sendSMS("User " + user + " logged out.");
    }

    public void printBalance(String user) {
        System.out.println("Current Balance: $" + dao.getBalance(user));
    }

    public void viewStatement(String user) {
        dao.viewStatement(user);
    }
}