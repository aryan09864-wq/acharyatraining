package com.bank.service;

public class FraudDetectionEngine {
    public boolean isFraudulent(double amount) {
        if (amount > 10000) {
            System.out.println("🚨 FRAUD ALERT: Transaction exceeds absolute safety limits.");
            return true; 
        }
        return false;
    }
}