package com.bank.service;
import java.util.Random;

public class FaceRecognitionService {
    public boolean verifyFace() {
        System.out.println("[SYSTEM] Initializing Biometric Scanner... . . .");
        boolean isMatch = new Random().nextInt(100) < 95; 
        if (isMatch) System.out.println("✅ Biometric Match Confirmed.");
        else System.out.println("❌ Biometric Mismatch! Access Denied.");
        return isMatch;
    }
}